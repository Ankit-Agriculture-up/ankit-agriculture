ANKIT AGRICULTURE WEBSITE
1. Extract the ZIP file.
2. Open index.html in Chrome to preview.
3. Images are loaded from Unsplash, so internet is required for photos.
4. Phone numbers and WhatsApp links are included. Replace text/photos as needed.
5. To publish online, upload index.html to your hosting provider or website builder.
